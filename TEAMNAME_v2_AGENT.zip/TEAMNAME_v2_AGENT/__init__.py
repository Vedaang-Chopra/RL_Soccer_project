from .agent import SoccerTorchAgent
